﻿namespace Main
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button_1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.table1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.database1DataSet = new Main.Database1DataSet();
            this.table1TableAdapter = new Main.Database1DataSetTableAdapters.Table1TableAdapter();
            this.Database = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.lEDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serialDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.művetelekToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leltárEllenőrzésToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leltar = new System.Windows.Forms.Button();
            this.Ell = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.table1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_1
            // 
            this.button_1.Location = new System.Drawing.Point(55, 214);
            this.button_1.Name = "button_1";
            this.button_1.Size = new System.Drawing.Size(137, 62);
            this.button_1.TabIndex = 3;
            this.button_1.Text = "Berakás";
            this.button_1.UseVisualStyleBackColor = true;
            this.button_1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(238, 214);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(140, 64);
            this.button2.TabIndex = 4;
            this.button2.Text = "Kivétel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(55, 158);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(323, 22);
            this.textBox1.TabIndex = 5;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // table1BindingSource
            // 
            this.table1BindingSource.DataMember = "Table1";
            this.table1BindingSource.DataSource = this.database1DataSet;
            // 
            // database1DataSet
            // 
            this.database1DataSet.DataSetName = "Database1DataSet";
            this.database1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // table1TableAdapter
            // 
            this.table1TableAdapter.ClearBeforeFill = true;
            // 
            // Database
            // 
            this.Database.Location = new System.Drawing.Point(20, 424);
            this.Database.Name = "Database";
            this.Database.Size = new System.Drawing.Size(98, 35);
            this.Database.TabIndex = 6;
            this.Database.Text = "Database";
            this.Database.UseVisualStyleBackColor = true;
            this.Database.Click += new System.EventHandler(this.Database_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.label1.Location = new System.Drawing.Point(160, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 46);
            this.label1.TabIndex = 7;
            this.label1.Text = "LED";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.lEDDataGridViewTextBoxColumn,
            this.serialDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.table1BindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(34, 292);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(361, 180);
            this.dataGridView2.TabIndex = 8;
            this.dataGridView2.Visible = false;
            // 
            // lEDDataGridViewTextBoxColumn
            // 
            this.lEDDataGridViewTextBoxColumn.DataPropertyName = "LED";
            this.lEDDataGridViewTextBoxColumn.HeaderText = "LED";
            this.lEDDataGridViewTextBoxColumn.Name = "lEDDataGridViewTextBoxColumn";
            // 
            // serialDataGridViewTextBoxColumn
            // 
            this.serialDataGridViewTextBoxColumn.DataPropertyName = "Serial";
            this.serialDataGridViewTextBoxColumn.HeaderText = "Serial";
            this.serialDataGridViewTextBoxColumn.Name = "serialDataGridViewTextBoxColumn";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.művetelekToolStripMenuItem,
            this.leltárEllenőrzésToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(429, 28);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // művetelekToolStripMenuItem
            // 
            this.művetelekToolStripMenuItem.Name = "művetelekToolStripMenuItem";
            this.művetelekToolStripMenuItem.Size = new System.Drawing.Size(89, 24);
            this.művetelekToolStripMenuItem.Text = "Művetelek";
            this.művetelekToolStripMenuItem.Click += new System.EventHandler(this.művetelekToolStripMenuItem_Click);
            // 
            // leltárEllenőrzésToolStripMenuItem
            // 
            this.leltárEllenőrzésToolStripMenuItem.Name = "leltárEllenőrzésToolStripMenuItem";
            this.leltárEllenőrzésToolStripMenuItem.Size = new System.Drawing.Size(131, 24);
            this.leltárEllenőrzésToolStripMenuItem.Text = "Leltár/Ellenőrzés";
            this.leltárEllenőrzésToolStripMenuItem.Click += new System.EventHandler(this.leltárEllenőrzésToolStripMenuItem_Click);
            // 
            // leltar
            // 
            this.leltar.Location = new System.Drawing.Point(238, 148);
            this.leltar.Name = "leltar";
            this.leltar.Size = new System.Drawing.Size(140, 55);
            this.leltar.TabIndex = 9;
            this.leltar.Text = "Leltár";
            this.leltar.UseVisualStyleBackColor = true;
            this.leltar.Visible = false;
            this.leltar.Click += new System.EventHandler(this.leltar_Click);
            // 
            // Ell
            // 
            this.Ell.Location = new System.Drawing.Point(55, 148);
            this.Ell.Name = "Ell";
            this.Ell.Size = new System.Drawing.Size(137, 55);
            this.Ell.TabIndex = 10;
            this.Ell.Text = "Ellenőrzés";
            this.Ell.UseVisualStyleBackColor = true;
            this.Ell.Visible = false;
            this.Ell.Click += new System.EventHandler(this.Ell_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(429, 484);
            this.Controls.Add(this.Ell);
            this.Controls.Add(this.Database);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.button_1);
            this.Controls.Add(this.leltar);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.table1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button_1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox1;
        private Database1DataSet database1DataSet;
        private System.Windows.Forms.BindingSource table1BindingSource;
        private Database1DataSetTableAdapters.Table1TableAdapter table1TableAdapter;
        private System.Windows.Forms.Button Database;
        private System.Windows.Forms.Label label1;
        private System.IO.FileSystemWatcher fileSystemWatcher1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn lEDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serialDataGridViewTextBoxColumn;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem művetelekToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leltárEllenőrzésToolStripMenuItem;
        private System.Windows.Forms.Button leltar;
        private System.Windows.Forms.Button Ell;
    }
}

